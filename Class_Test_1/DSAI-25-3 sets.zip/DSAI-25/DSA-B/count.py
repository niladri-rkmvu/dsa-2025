import argparse
from PyPDF2 import PdfReader
from collections import defaultdict

def count_words_in_pdf(pdf_path, words):
    word_counts = defaultdict(int)
    with open(pdf_path, 'rb') as f:
        reader = PdfReader(f)
        for page in reader.pages:
            text = page.extract_text()
            if text:
                text = text.lower()
                for word in words:
                    word_counts[word.lower()] += text.count(word.lower())
    return word_counts

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Count multiple word occurrences in a PDF (PyPDF2).")
    parser.add_argument("pdf_file", help="Path to the PDF file")
   # parser.add_argument("words", nargs='+', help="List of words to search for")
    
    args = parser.parse_args()
    total_count=0
    words_arr = ("[TM]", "[JM]", "[SP]", "[SS]", "[SD]")
    results = count_words_in_pdf(args.pdf_file, words_arr)
    for word, count in results.items():
        print(f"'{word}' appears {count} times in '{args.pdf_file}'.")
        total_count +=count
        
    print(f"total count is {total_count}")

